# ============================================================================
# MOSQUITTO TLS SETUP - WINDOWS BROKER
# Manual Instructions
# ============================================================================

## **BƯỚC 1: Chuẩn bị trên máy PC (Development)**

### Copy các file cần thiết
```powershell
# Thư mục này nên có:
# - mqtt_tls_certs/
#   - ca.crt
#   - server.crt
#   - server.key
# - setup_mosquitto_tls.bat (file vừa tạo)

# Nén toàn bộ vào ZIP
Compress-Archive -Path mqtt_tls_certs, setup_mosquitto_tls.bat -DestinationPath mosquitto_tls_setup.zip

# Copy sang broker (10.77.190.75) qua:
# - USB drive
# - Network share
# - Email
# - Cloud share (OneDrive, Google Drive)
```

---

## **BƯỚC 2: Trên Broker Machine (10.77.190.75)**

### 2.1 Tìm vị trí Mosquitto
```
C:\Program Files\mosquitto\     (Default Windows installation)
```

### 2.2 Extract ZIP sang folder Mosquitto
```
1. Tìm file mosquitto_tls_setup.zip
2. Right-click > Extract All
3. Extract vào: C:\Program Files\mosquitto\
   Sau khi extract, bạn sẽ có:
   - C:\Program Files\mosquitto\mqtt_tls_certs\
   - C:\Program Files\mosquitto\setup_mosquitto_tls.bat
```

### 2.3 Chạy setup script
```
1. Mở Command Prompt (cmd.exe) as Administrator
   - Cách: Windows Start > type "cmd" > right-click > "Run as administrator"

2. Navigate đến folder:
   cd C:\Program Files\mosquitto

3. Run script:
   setup_mosquitto_tls.bat

4. Script sẽ tự động:
   - Copy chứng chỉ vào C:\Program Files\mosquitto\certs\
   - Update mosquitto.conf với TLS config
   - Restart Mosquitto service
```

### 2.4 Verify setup
```
# Kiểm tra ports đang listen
netstat -ano | findstr "1883 8883"

# Kiểm tra service status
wmic service where name="mosquitto" get status

# Xem Mosquitto logs
type "C:\Program Files\mosquitto\log\mosquitto.log" | findstr TLS
```

---

## **BƯỚC 3: Verify trên Development Machine**

```powershell
# Chạy test TLS
powershell -ExecutionPolicy Bypass -File test_mosquitto_tls.ps1

# Nếu thấy:
# [OK] Port 8883 (TLS MQTT): OPEN
# [OK] TLS Certificate Verification PASSED
# => Setup thành công!
```

---

## **BƯỚC 4: Nếu có lỗi**

**Lỗi: "Port 8883 not listening"**
- Kiểm tra mosquitto.conf có listener 8883 không
- Kiểm tra logs: `type C:\Program Files\mosquitto\log\mosquitto.log`
- Restart service: `net stop mosquitto` và `net start mosquitto`

**Lỗi: "Certificate verification failed"**
- Verify chứng chỉ: `openssl x509 -in C:\Program Files\mosquitto\certs\ca.crt -text -noout`
- Check permissions trên cert files

**Lỗi: "Access denied"**
- Chạy Command Prompt as Administrator
- Check mosquitto service không bị disabled

---

## **BƯỚC 5: Sau khi TLS OK**

Quay lại Development Machine và chạy:

```bash
# Python backend (MQTT to Firebase)
python mqtt_to_firebase_tls.py

# Monitor ESP32
platformio device monitor -p COM9 -b 115200
```

---

## **Tóm tắt file cần copy sang broker**

```
mqtt_tls_setup/
├── mqtt_tls_certs/
│   ├── ca.crt
│   ├── server.crt
│   ├── server.key
│   └── ca.key (backup)
└── setup_mosquitto_tls.bat
```

**Thực hiện bây giờ:**
1. Nén 2 thứ trên thành ZIP
2. Copy sang broker
3. Chạy setup_mosquitto_tls.bat trên broker (as Administrator)
3. Report kết quả
