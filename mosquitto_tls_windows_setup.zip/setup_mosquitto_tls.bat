@echo off
REM ============================================================================
REM setup_mosquitto_tls.bat
REM Setup Mosquitto TLS on Windows broker
REM Run as Administrator: setup_mosquitto_tls.bat
REM ============================================================================

setlocal enabledelayedexpansion

echo.
echo ========================================================
echo   MOSQUITTO TLS SETUP FOR WINDOWS
echo ========================================================
echo.

REM Configuration
set "CERT_SOURCE_DIR=%~dp0mqtt_tls_certs"
set "MOSQUITTO_DIR=C:\Program Files\mosquitto"
set "MOSQUITTO_CONF=%MOSQUITTO_DIR%\mosquitto.conf"
set "CERT_TARGET_DIR=%MOSQUITTO_DIR%\certs"

REM Check if running as admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] This script must run as Administrator
    echo Please right-click and select "Run as administrator"
    pause
    exit /b 1
)
echo [OK] Running as Administrator
echo.

REM Step 1: Verify certificates exist
echo [STEP 1] Verifying certificates...
if not exist "%CERT_SOURCE_DIR%\ca.crt" (
    echo [ERROR] CA certificate not found: %CERT_SOURCE_DIR%\ca.crt
    pause
    exit /b 1
)
if not exist "%CERT_SOURCE_DIR%\server.crt" (
    echo [ERROR] Server certificate not found: %CERT_SOURCE_DIR%\server.crt
    pause
    exit /b 1
)
if not exist "%CERT_SOURCE_DIR%\server.key" (
    echo [ERROR] Server key not found: %CERT_SOURCE_DIR%\server.key
    pause
    exit /b 1
)
echo [OK] All certificates found
echo     - %CERT_SOURCE_DIR%\ca.crt
echo     - %CERT_SOURCE_DIR%\server.crt
echo     - %CERT_SOURCE_DIR%\server.key
echo.

REM Step 2: Verify Mosquitto installation
echo [STEP 2] Checking Mosquitto installation...
if not exist "%MOSQUITTO_DIR%" (
    echo [ERROR] Mosquitto not found at: %MOSQUITTO_DIR%
    echo Please install Mosquitto first: https://mosquitto.org/download/
    pause
    exit /b 1
)
echo [OK] Mosquitto found: %MOSQUITTO_DIR%
echo.

REM Step 3: Create certificate directory
echo [STEP 3] Creating certificate directory...
if not exist "%CERT_TARGET_DIR%" (
    mkdir "%CERT_TARGET_DIR%"
    echo [OK] Created: %CERT_TARGET_DIR%
) else (
    echo [OK] Directory exists: %CERT_TARGET_DIR%
)
echo.

REM Step 4: Copy certificates
echo [STEP 4] Copying certificates...
copy "%CERT_SOURCE_DIR%\ca.crt" "%CERT_TARGET_DIR%\" >nul
if %errorlevel% equ 0 (
    echo [OK] Copied ca.crt
) else (
    echo [ERROR] Failed to copy ca.crt
    pause
    exit /b 1
)

copy "%CERT_SOURCE_DIR%\server.crt" "%CERT_TARGET_DIR%\" >nul
if %errorlevel% equ 0 (
    echo [OK] Copied server.crt
) else (
    echo [ERROR] Failed to copy server.crt
    pause
    exit /b 1
)

copy "%CERT_SOURCE_DIR%\server.key" "%CERT_TARGET_DIR%\" >nul
if %errorlevel% equ 0 (
    echo [OK] Copied server.key
) else (
    echo [ERROR] Failed to copy server.key
    pause
    exit /b 1
)
echo.

REM Step 5: Backup mosquitto.conf
echo [STEP 5] Backing up mosquitto.conf...
if exist "%MOSQUITTO_CONF%" (
    for /f "tokens=2-4 delims=/ " %%a in ('date /t') do set "TIMESTAMP=%%c-%%a-%%b_%H%M%S"
    copy "%MOSQUITTO_CONF%" "%MOSQUITTO_CONF%.bak" >nul
    echo [OK] Backup created: mosquitto.conf.bak
) else (
    echo [WARNING] mosquitto.conf not found, creating new...
)
echo.

REM Step 6: Create/Update mosquitto.conf with TLS
echo [STEP 6] Updating mosquitto.conf with TLS configuration...

setlocal disabledelayedexpansion

(
    echo # ============================================================================
    echo # Mosquitto Configuration with TLS Support
    echo # ============================================================================
    echo.
    echo # Default listener (plain MQTT - port 1883^)
    echo listener 1883
    echo protocol mqtt
    echo allow_anonymous true
    echo.
    echo # TLS listener (MQTT over SSL/TLS - port 8883^)
    echo listener 8883
    echo protocol mqtt
    echo cafile %MOSQUITTO_DIR%\certs\ca.crt
    echo certfile %MOSQUITTO_DIR%\certs\server.crt
    echo keyfile %MOSQUITTO_DIR%\certs\server.key
    echo tls_version tlsv1.2
    echo allow_anonymous true
    echo.
    echo # Logging
    echo log_dest file %MOSQUITTO_DIR%\log\mosquitto.log
    echo log_dest stdout
) > "%MOSQUITTO_CONF%"

if %errorlevel% equ 0 (
    echo [OK] mosquitto.conf updated with TLS configuration
) else (
    echo [ERROR] Failed to update mosquitto.conf
    pause
    exit /b 1
)
echo.

REM Step 7: Verify configuration
echo [STEP 7] Verifying Mosquitto configuration...
cd /d "%MOSQUITTO_DIR%"
mosquitto.exe -c "%MOSQUITTO_CONF%" --test-config
if %errorlevel% equ 0 (
    echo [OK] Configuration is valid
) else (
    echo [ERROR] Configuration test failed
    pause
    exit /b 1
)
echo.

REM Step 8: Stop existing Mosquitto service
echo [STEP 8] Stopping Mosquitto service...
net stop mosquitto >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Mosquitto service stopped
    timeout /t 2 >nul
) else (
    echo [INFO] Mosquitto service was not running
)
echo.

REM Step 9: Start Mosquitto service with new config
echo [STEP 9] Starting Mosquitto service...
net start mosquitto >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Mosquitto service started
    timeout /t 2 >nul
) else (
    echo [ERROR] Failed to start Mosquitto service
    echo Try manually: net start mosquitto
    pause
    exit /b 1
)
echo.

REM Step 10: Verify ports are listening
echo [STEP 10] Verifying ports...
netstat -ano | findstr "1883"
if %errorlevel% equ 0 (
    echo [OK] Port 1883 (plain MQTT) is listening
) else (
    echo [WARNING] Port 1883 is not listening
)

netstat -ano | findstr "8883"
if %errorlevel% equ 0 (
    echo [OK] Port 8883 (TLS MQTT) is listening
) else (
    echo [ERROR] Port 8883 is not listening
    echo Check: Mosquitto service status and mosquitto.log
)
echo.

REM Summary
echo ========================================================
echo   TLS SETUP COMPLETED
echo ========================================================
echo.
echo Summary:
echo   - Certificates: %CERT_TARGET_DIR%
echo   - Configuration: %MOSQUITTO_CONF%
echo   - Plain MQTT: Port 1883
echo   - TLS MQTT: Port 8883
echo.
echo Log file: %MOSQUITTO_DIR%\log\mosquitto.log
echo.
echo Check log for any errors:
type "%MOSQUITTO_DIR%\log\mosquitto.log" | findstr /r "error Error ERROR"
echo.
pause
